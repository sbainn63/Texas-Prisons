gaps.plot(synth_out, dataprep_out)
